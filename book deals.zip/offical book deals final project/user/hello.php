<?php 
 session_start();
 require('includes/config.php');
 $id=$_SESSION['uid'];
 $t=mysqli_query($conn,"select * from cart where u_id='".$id."';");
 while($row=mysqli_fetch_assoc($t))
 {
 	$query=mysqli_query($conn,"select * from shipping_details where u_id=$id");
 	$r=mysqli_fetch_assoc($query);
 	$bid=$row['b_id'];
 	$name=$row['b_nm'];
 	$publisher=$row['b_publisher'];
 	$phone=$_SESSION['phone'];
 	$address=$_SESSION['address'];
 	$price=$row['Rate'];
 	$true=mysqli_query($conn,"INSERT INTO transaction(u_id, b_id, `b_nm`, `b_publisher`, `address`, `phone`,Price) VALUES ($id,$bid,'$name','$publisher','$address','$phone',$price);");	
 	if($true)
  	{
    		mysqli_query($conn,"delete from cart where u_id='$id'");
	}
 }
 ?>


 <html>
 <head>
 	<title> Last page</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
    	p.a { 
    word-spacing: normal;
    }
    </style>

		<?php
			include("includes/head.inc.php");
		?>
	
 </head>
 <body>

 	



    
 	<div id="header">
					<div id="menu">
						<?php
							include("includes/menu.inc.php");
						?>
					</div>
				</div>
				
				<div id="logo-wrap">
					<div id="logo">
							<?php
								include("includes/logo.inc.php");
							?>
					</div>
				</div>


 	<?php
 	        	   echo"we have recived your order and here are your details. "; 
 	        	 ?>
				
				
 	    <?php
 	    	$f_id=$_SESSION['uid'];
 	        $q='select * from transaction where u_id='.$f_id.';';
 	       $query= mysqli_query($conn,$q);

 	  	      	while($row=mysqli_fetch_assoc($query)) 
 	       { 
 	          $q=mysqli_query($conn,"select * from user where u_id=$f_id");
 	          	$r=mysqli_fetch_assoc($q); 	     	 	     
 	        ?>
 	       
 	        <table style="border-width: 9px;border-style: solid; border-bottom-color: black;font-family:TimesNewRoman; font-style: italic;  font-size: large;">
 	        	<th> address</th>
 	        	<tr style="border-width: 5px;border-style: solid;border-bottom-color: coral; font-family:TimesNewRoman; font-style: italic;   font-size: large;  font-variant: small-caps; font-weight: bold;">
 	        		<tr>
 	        		<td style="border-width: 5px;border-style: solid;border-bottom-color: black; font-family:TimesNewRoman; font-style: italic;  font-size: large;  font-variant: small-caps; font-weight: bold;">
 	        			<?php echo $row['address']; ?>
 	        		</td>
 	        	</tr>
 	        	<th> Book Name   </th>
 	        	<tr>
 	        		<td style="border-width: 5px;border-style: solid;border-bottom-color: grey; font-family:TimesNewRoman; font-style: italic;  font-size: large;  font-variant: small-caps; font-weight: bold;">
 	        			<?php echo $row['b_nm']; ?>
 	        		</td>
 	        	</tr>
 	        	<th> Name</th>
 	        	<tr>
 	        		<td style="border-width: 5px;border-style: solid; border-bottom-color: black;font-family:TimesNewRoman;font-style: italic;  font-size: large;  font-variant: small-caps; font-weight: bold;">
 	        			<?php echo $r['u_fnm']." ".$r['u_unm']; ?>
 	        		</td>
 	        	</tr>

 	        	<th>Book_id</th>
 	        	<tr>
 	        		<td style="border-width: 5px;border-style: solid; border-bottom-color: coral;font-family:TimesNewRoman;font-style: italic; font-size: large;  font-variant: small-caps; font-weight: bold;">
 	        			<?php echo $row['b_id']; ?>
 	        		</td>
 	        	</tr>
 	        	<th>Book publsiher</th>
 	        	<tr>
 	        		<td style="border-width: 5px;border-style: solid; border-bottom-color: coral; font-family:TimesNewRoman;font-style: italic; font-size: large;  font-variant: small-caps; font-weight: bold;">
 	        			<?php echo $row['b_publisher']; ?>
 	        		</td>
 	        	</tr>
 	        	<th> phone Number</th>
 	        	<tr>
 	        		<td style="border-width: 5px;border-style: solid; border-bottom-color: coral; font-family:TimesNewRoman;font-style: italic; font-size: large;  font-variant: small-caps; font-weight: bold;">
 	        			<?php echo $row['phone']; ?>
 	        		</td>
 	        	</tr>
 	        	
 	        	
 	        	<th> Date and time</th>
 	        		<tr>
 	        		<td style="border-width: 5px;border-style: solid; font-family:TimesNewRoman;font-style: italic; font-size: large;  font-variant: small-caps; ">
 	        			<?php echo $row['datetime'];
 	        			 ?>

 	        		</td>
 	        	</tr>
 	        	</tr>
				<th>Total</th>
 	        		<tr>
 	        		<td style="border-width: 5px;border-style: solid; font-family:TimesNewRoman;font-style: italic; font-size: large;  font-variant: small-caps; ">
 	        			<?php echo $row['Price'];
 	        			 ?>

 	        		</td>
 	        	</tr>
 	        	</tr> 	        	
 	        </table> <?php }  ?>
 	        
            
			
 	    </body>
</html>