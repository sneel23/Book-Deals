<?php session_start();
require('includes/config.php');
?>


<html>
<head>
		<?php
			include("includes/head.inc.php");
		?>


</head>

<body>
			<!-- start header -->
				<div id="header">
					<div id="menu">
						<?php
							include("includes/menu.inc.php");
						?>
					</div>

					
				</div>
				<div id="logo-wrap">
				<div id="logo">
						<?php
							include("includes/logo.inc.php");
						?>
				</div>
				</div>
					



			<!-- end header -->
			<!-- start page -->

				<div id="page">
					<!-- start content -->
					<div id="content">
						<div class="post">
							<h1 class="title">Viewcart</h1>
							<div class="entry">
						
							<pre><?php
							//	print_r($_SESSION);
							?></pre>
						
							<form action="process_cart.php" method="POST">
							<table width="100%" border="0">
								<tr >
									<td> <b>No </b> </td>
									<td> <b>Book Name</b> </td>
									<td> <b>Publisher</b> </td>
									<td> <b>price</b> </td>
									<td> <b> Qty</b></td>
									<td> <b>Rate</b> </td>
									<td> <b>Delete</b> </td>
								</tr>
								<tr><td colspan="7"><hr style="border:1px Solid #a1a1a1;"></tr>
							
								<?php
								$id=$_SESSION['uid'];
								//echo $id;
								$e='select * from cart where u_id='.$id.';';
								$sql=mysqli_query($conn,$e);
									$tot = 0;
									$i = 1;
									while($x=mysqli_fetch_assoc($sql))
									{	$id=$x['b_id'];
										$query=mysqli_query($conn,"select * from book where b_id=$id;");
										$row=mysqli_fetch_assoc($query);
										echo '
											<tr>
											<td> '.$row['b_subcat'].'</td>
											<td> '.$x['b_nm'].'</td>
											<td> '.$x['b_publisher'].'</td>
                                            <td> '.$row['b_price'].'</td> 
											<td> '.$x['qty'].'</td>
											 <td> '.$x['qty']*$x['Rate'].'</td>
											<td> <a href="process_cart.php?id='.$id.'&delete=true">Delete</a></td>
										</tr>';
										$tot = $tot + ($x['qty']*$row['b_price']);
										$i++;
									}
								?>
							<tr><td colspan="7"><hr style="border:1px Solid #a1a1a1;"></tr>
								
							<tr>
							<td colspan="6" align="right">
							<h4>Total:</h4>
							
							</td>
							<td> <h4><?php echo $tot; ?> </h4></td>
							</tr>
							<tr><td colspan="7"><hr style="border:1px Solid #a1a1a1;"></tr>
							
							<Br>
								</table>						

								<br><br>
							<center>
								
								<?php

								if (isset($_SESSION['status']))
									{
							echo '  
							<a href="checkout.php">CONFIRM & PROCEED<a/></a>';

							
						}
						else
							{
													echo '<img src="images/cart.jpg"><br><a href="register.php"> <h4>Please Login..</h4></a>';
													}
											
										?>

							</center>
							</form>
							</div>
							
						</div>
						
					</div>
					<!-- end content -->
					<!-- start sidebar -->




			 					<div id="sidebar">
							<?php
								include("includes/search.inc.php");
							?>
					</div>


					<!-- end sidebar -->
				<div style="clear: both;">&nbsp;</div>
			</div>
			<!-- end page -->
			
			<!-- start footer -->
			<div id="footer">
						<?php
							include("includes/footer.inc.php");
						?>
			</div>
			<!-- end footer -->
</body>
</html>
