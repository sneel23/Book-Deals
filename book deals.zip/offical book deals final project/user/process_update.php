 <?php 
   session_start();
    if (!session_is_registered(unm))
  {
   header("location:index.php");
}
?>
<?php
  include("includes/head.inc.php");


 $username = $_POST['USERNAME'];
 $password = $_POST['pwd'];
 $sessions = $_SESSION['unm'];

  $sql = "UPDATE user_info SET u_unm= '$username',u_pwd='$password' WHERE username = '$sessions'";
  $result= mysql_query($sql);

  if($result)
  {
    echo"updated"; 

}



  mysql_close();
  ?>