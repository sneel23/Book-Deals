<?php session_start();?>


<html>
<head>
		<?php
			include("includes/head.inc.php");
		?>
</head>

<body>
			<!-- start header -->
				<div id="header">
					<div id="menu">
						<?php
							include("includes/menu.inc.php");
						?>
					</div>
				</div>
				
				<div id="logo-wrap">
					<div id="logo">
							<?php
								include("includes/logo.inc.php");
							?>
					</div>
				</div>

				<table align="center">
					<form action="process_update.php" method="post">
					
												<tr><td>&nbsp;</tr>
												
												<tr>
													 <td><b> Enter Current Username :</b>&nbsp;&nbsp;</td>
													 <td><input type='text' size="30" maxlength="30" name='USERNAME'></td>
													 <td>&nbsp;</td>
													
												</tr>
												
												<tr><td>&nbsp;</tr>

												<tr>
													 <td><b> Enter New User Name :</b>&nbsp;&nbsp;</td>
													 <td><input type='text' size="30" maxlength="30" name='USERNAME'></td>
													 <td>&nbsp;</td>
													
												</tr>
												
												

                                          
												<tr>
													<td colspan='2' align='center'>
														<br>
														<br>
														 <input type='submit' value=" submit  ">
													</td>
												</tr>

				</td>
			</tr>
		</td>
	</tr>
				</form>
			</table>
				<br>
				<br>
				<br>
				<br>


			<!-- start footer -->
			<div id="footer">
						<?php
							include("includes/footer.inc.php");
						?>
			</div>
			<!-- end footer -->
</body>
</html>