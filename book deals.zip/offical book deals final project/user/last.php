<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
          <h4> WE have recived your order. we will diliver your order as soon as possible</h4>
</body>
</html>