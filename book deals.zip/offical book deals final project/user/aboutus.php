<?php session_start();?>


<html>
<head>
		<?php
	
	
		include("includes/head.inc.php");
		?>

	

</head>

<body>



	<div id="header">
					<div id="menu">
						<?php
							include("includes/menu.inc.php");
						?>
					</div></div>
		<div id="logo-wrap">

				

					<div id="logo">
							<?php
								include("includes/logo.inc.php");
							?>
					</div>
				<br>
				<br>
				<br><br><br>
				
							<h1>About Us</h1>
							<p>
							This website is the dedication and encouragement of many individuals. And we would like to thank guide and books and sites from where we got useful help In accomplishing the task of made this website.


We enjoyed made this website and hope you will enjoy function of this website and using it for your business and can take advice from our expertise. Please let me know if you have any suggestion or find any error and bugs to improve the website.


We are indebted our Faculties and those person who helped us, inspired us and given moral support to us and encouragement who helped us, inspired us  various ways, in accomplishing the task.

</p>
						</div>
					
	<!-- start sidebar -->
	

					<!-- end sidebar -->

						<div id="footer">
						<?php
							include("includes/footer.inc.php");
						?>
			</div>	
					
					
</body>
</html>
