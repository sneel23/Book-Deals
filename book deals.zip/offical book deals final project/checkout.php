<?php
 session_start();
 extract($_POST);
 extract($_SESSION);
 
require('includes/config.php'); 	
	//echo $uid;
	if(isset($submit))
	{
	$query="insert into shipping_details(name,address,postal_code,city,state,phone,f_id) values('$name','$address','$pc','$city','$state','$phone','$uid')";
	
	$res=mysqli_query($conn,$query) or die("Can't Execute Query...");
	header("location:payment_details.php");
	}


?>

<html>
<head>
		<?php
			include("includes/head.inc.php");
		?>
</head>

<body>
			<!-- start header -->
				<div id="header">
					<div id="menu">
						<?php
							include("includes/menu.inc.php");
						?>
					</div>
				</div>
				<div id="logo-wrap">
				<div id="logo">
						<?php
							include("includes/logo.inc.php");
						?>
				</div>
				</div>
				

		<table align="center">
      
    		<form id="contactform" method="post">
    		<tr>
    			<p class="contact">
    				
    					<td><label for="name">Name</label></p> </td>
    			<td><input id="name" name="name" placeholder="First and last name" required="" tabindex="1" type="text"></td>
    		</tr>
    			 <tr>
    			<p class="contact"><td><label for="email">Address</label></p></td> 
    			<td><textarea id="address" name="address" placeholder="Address" required="" cols="25" row="30"type="email"> </textarea></td>>
              </tr>  
              <tr>
                <p class="contact"><td><label for="username">Postal Code</label></p> </td>
    			<td><input id="pc" name="pc" placeholder="201001" required="" tabindex="2" type="text"></td> 
    		</tr>
    		<tr>

                <p class="contact"><td><label for="city">City</label></p></td> 
    			<td><input type="text" id="city" name="city" required="" placeholder="delhi"></td>
    		</tr>
    		<tr>
                <td><p class="contact"><label for="state">State</label></p> </td>
    			<td><input type="text" id="state" name="state" required="" placeholder="delhi"></td> 
    		</tr>
    		<tr>

            <p class="contact"><td><label for="phone">Mobile phone</label></p></td> 
           <td> <input id="phone" name="phone" placeholder="phone number" required="" type="text"> <br></td>
           <tr>
           <td> <input class="buttom" name="submit" id="submit" tabindex="5" value="Confirm & Proceed" type="submit"></td></tr> 	 
   </form> 

</div>      
</div>
</table>s
</body>