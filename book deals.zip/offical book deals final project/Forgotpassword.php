<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
            
    require '../user/includes/config.php';
    
    if($_POST)
    {
        $email = $_POST['email'];
        
        $selectq = mysqli_query($connection, "select * from tbl_user where user_email='{$email}'") or die(mysqli_error($connection));
        $count = mysqli_num_rows($selectq);
        $row = mysqli_fetch_array($selectq);
        
        if($count>0)
        {
            require './vendor/autoload.php';

            $mail = new PHPMailer(true);                             
            try {
            $mail->SMTPDebug = 20;
            $mail->isSMTP();
            $mail->Host = ' smtp.yahoo.com';
            $mail->SMTPAuth = true;     
            $mail->Username = 'bookdeal2018@gmail.com';   
            $mail->Password = 'book@2018';  
            $mail->SMTPSecure = 'tls';   
            $mail->Port = 437; 
            $mail->setFrom('bookdeal2018@gmail.com', 'Book Deal');
            $mail->addAddress($email, $email);
            $mail->isHTML(true);              
            $mail->Subject = 'Forgot Password';
            $mail->Body = "Hii $email your Password is {$row['user_password']}" ;
            $mail->AltBody = "Hii $email your Password is {$row['user_password']}" ;

            $mail->send();
            
            echo "<script>alert('Your Password has been Send on your Email ID.')</script>" ;
            } catch (Exception $e) {
                echo 'Mail could not be sent. Mailer Error: ', $mail->ErrorInfo;
            }
        } else {
            echo "<script>alert('Email Not Found')</script>";
        }
       
    }
?>    <!DOCTYPE html>
<html lang="en">

<head>
    <!-- Title Page-->
    <title>FORGOT PASSWORD</title>

  
</head>
<body class="animsition">
    <div class="page-wrapper">     
        <div class="page-content--bge5">
            <div class="container">
                <div class="login-wrap">
                    <div class="login-content">
                        <div class="login-logo">
                            <?php
                            include("includes/logo.inc.php");                                  
                            ?>
                        </div>
                        <div class="login-form">
                            <form action="" method="post">
                                <div class="form-group">
                                    <label>Email Id</label>
                                    <input class="au-input au-input--full" type="email" name="email" placeholder="ENTER YOUR EMAIL ID">
                                </div>
                                <button class="au-btn au-btn--block au-btn--green m-b-20" type="submit">submit</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="vendor/slick/slick.min.js">
    </script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js">
    </script>

    <!-- Main JS-->
    <script src="js/main.js"></script>

</body>

</html>
