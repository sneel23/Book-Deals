<?php 
$conn=mysqli_connect("localhost","root","","book_deals")or die("Can't Connect...");
	
?>