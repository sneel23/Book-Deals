<div id="footer-wrap">
	<p id="legal">WELCOME TO BOOK DEALS WEBSITE  </p>
	</div>