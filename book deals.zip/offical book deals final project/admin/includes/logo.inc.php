<!DOCTYPE html>
<html>
<head>
	<title>
	</title>
</head>
<body>
               <img src="images/slider/LOGO.png" alt="logo">
</body>
</html>
