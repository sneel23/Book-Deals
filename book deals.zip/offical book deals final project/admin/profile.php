<?php 
 session_start();
 require('includes/config.php');
 ?>
<html>
<head>	
</head>
<body>




<?php 
 	                    $f_id=$_SESSION['id'];
 	        			$hi="select u_fnm,u_nm,u_gender from user where u_id='$f_id2'";
 	        			$er=mysqli_query($conn,$hi);
 	        			
 	        			while($ec=mysqli_fetch_assoc($er))
 	        			{
 	        			echo $ec['u_fnm'];
 	        			echo $ec['u_nm'];
 	        			echo $ec['u_gender'];
 	        			}
 	        			
 ?>
 </body>
 </html>