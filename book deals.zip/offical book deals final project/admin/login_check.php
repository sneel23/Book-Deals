<?php 
session_start();
if (isset($_POST['login_user']))
{
    $con = mysqli_connect("localhost","root","");
    mysqli_select_db($con,"book_deals");
    $username=isset($_POST['username'])?$_POST['username']:'';
    $password=isset($_POST['password'])?$_POST['password']:'';
   	$res=mysqli_query($con,"select * from user where USERNAME='$username'");
   	$row=mysqli_fetch_assoc($res);
    var_dump($row);
   	if($username==$row['USERNAME'] && $password==$row['u_pwd'])
   	{
   		$_SESSION['id']=$row['u_id'];
   		$_SESSION['username']=$row['USERNAME'];
   		$_SESSION['name']=$row['u_fnm'];
      header("location:index.php");
    }
   	else
   	{
      header("location:login.php");
      var_dump($con);
   	}
  	mysqli_close($con);
}
?>
