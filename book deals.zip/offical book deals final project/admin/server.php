<?php
session_start();

// initializing variables
$username = "";
$email    = "";
$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'book_deals');

// REGISTER USER
if (isset($_POST['reg_user'])) {
  // receive all input values from the form
  $USERNAME = mysqli_real_escape_string($db, $_POST['username']);
  $email = mysqli_real_escape_string($db, $_POST['Email']);
  $password_1 = mysqli_real_escape_string($db, $_POST['password_1']);
  $password_2 = mysqli_real_escape_string($db, $_POST['password_2']);
  $firstname = mysqli_real_escape_string($db, $_POST['firstname']);
  $lastname = mysqli_real_escape_string($db, $_POST['lastname']);
  $city = mysqli_real_escape_string($db, $_POST['city']);
  $contact = mysqli_real_escape_string($db, $_POST['contact']);
  $gender = mysqli_real_escape_string($db, $_POST['rdo_btn']);



 
  if (empty($USERNAME)) { array_push($errors, "Username is required"); }
  if (empty($email)) { array_push($errors, "Email is required"); }
  if (empty($password_1)) { array_push($errors, "Password is required"); }
  if (empty($firstname)) { array_push($errors, "first name is required");}
  if (empty($lastname)) { array_push($errors, "lastname is required"); }
  if (empty($city)) { array_push($city, "city is required");}
  if (empty($contact)) { array_push($errors, "contact is required"); }  
  if ($password_1 != $password_2) {
	array_push($errors, "The two passwords do not match");
  }

  $result = mysqli_query($db, "select * from user where USERNAME='".$username."' LIMIT 1;");
  $user = mysqli_fetch_assoc($result);
  if ($user) { // if user exists
    if ($user['username'] == $USERNAME) 
    {
      array_push($errors, "Username already exists");
    }

    if ($user['email'] == $email)
     {
      array_push($errors, "email already exists");
    }
  }
    foreach ($errors as $error)  
      echo $error;  
  // Finally, register user if there are no errors in the form
  if (count($errors) == 0) {

  	$res=mysqli_query($db, "insert into user (USERNAME,u_email,u_pwd,u_fnm,u_unm,u_city,u_contact,u_gender) 
          VALUES('$USERNAME', '$email', '$password_1','$firstname','$lastname','$city',$contact,'$gender')");
    if($res==true)
    {
  	 $_SESSION['username'] = $USERNAME;
  	 $_SESSION['success'] = "You are now logged in";
      header("location: index.php");
    }
    
  }
}
