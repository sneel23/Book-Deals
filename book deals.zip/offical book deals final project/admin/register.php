<?php include '\server.php'; 
?>
<!DOCTYPE html>
<html>
<head>
  <title>Registration system PHP and MySQL</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="header">
  	<h2>Register</h2>
  </div>
	
  <form method="post" action="register.php">
 
  	<div class="input-group">
  	  <label>username</label>
  	  <input type="text" name="username"> 
  	</div>
    <div class="input-group">
      <label>first name</label>
      <input type="text" name="firstname"> 
    </div>
  	<div class="input-group">
  	  <label>last Name</label>
  	  <input type="text" name="lastname"> 
  	</div>
  	<div class="input-group">
  	  <label>contact</label>
  	  <input type="text" name="contact"> 
  	</div>
  	<div class="input-group">
  	  <label> city</label>
  	  <input type="text" name="city"> 
  	  
  	</div>

  	
  	<div class="input-group">
  	  <label>Email</label>
  	  <input type="email" name="Email">
  	</div>
  	<div class="input-group">
  	  <label>Password</label>
  	  <input type="password" name="password_1">
  	</div>
  	<div class="input-group">
  	  <label>Confirm password</label>
  	  <input type="password" name="password_2">
  	</div>
 
  	</div>
      <table> 
        <Tr>
          <td>  
              Gender 
          </td>
          <td> 
              &nbsp &nbsp&nbsp&nbsp&nbsp<input type="radio" name="rdo_btn" value="male" >M
          </td>
          <td> 
              &nbsp&nbsp&nbsp&nbsp&nbsp<input type="radio" name="rdo_btn" value="female" > F
          </td>
        </Tr>
      </table>
        <div class="input-group">
      <button type="submit" class="btn" name="reg_user">Register</button>
  </form>
</body>
</html>