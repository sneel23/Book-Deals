<?php 
 session_start();
 require('includes/config.php');
 ?>


 <html>
 <head>
 </head>
 <body>
 	    <?php
 	    	$f_id=$_SESSION['id'];
 	        $q="select * from transaction ;";
 	       $query= mysqli_query($conn,$q);
 	       
 	      	while ($row=mysqli_fetch_assoc($query)) 
 	       { 	 	     	 	     
 	        ?>
 	        <table style="border-width: 1px;border-style: solid;">
 	        	<tr style="border-width: 1px;border-style: solid;">
 	        		<td style="border-width: 1px;border-style: solid;">
 	        			<?php echo $row['address']; ?>
 	        		</td>
 	        		<td style="border-width: 1px;border-style: solid;">
 	        			<?php echo $row['b_id']; ?>
 	        		</td>
 	        		<td style="border-width: 1px;border-style: solid;">
 	        			<?php echo $row['b_nm']; ?>
 	        		</td>
 	        		<td style="border-width: 1px;border-style: solid;">
 	        			<?php echo $row['b_publisher']; ?>
 	        		</td>
 	        		<td style="border-width: 1px;border-style: solid;">
 	        			<?php echo $row['datetime']; ?>
 	        		</td>
 	        		<td style="border-width: 1px;border-style: solid;">
 	        			<?php echo $row['phone']; ?>
 	        		</td>
 	        		
 	        		<td style="border-width: 1px;border-style: solid;">
 	        			<?php echo $row['u_id']; ?>
 	        		</td>
 	        	</tr>
 	        </table> <?php }?>
 	    </body>
</html>